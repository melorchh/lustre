-- ═══════════════════════════════════════════════════════════════
-- ToddCare — Complete Database Setup (with Laboratory Module)
-- ═══════════════════════════════════════════════════════════════

CREATE DATABASE IF NOT EXISTS toddcare;
USE toddcare;

-- ───────────────────────────────────────
-- TABLES
-- ───────────────────────────────────────

CREATE TABLE IF NOT EXISTS patients (
    id         INT AUTO_INCREMENT PRIMARY KEY,
    name       VARCHAR(255) NOT NULL,
    email      VARCHAR(255) UNIQUE NOT NULL,
    contact    VARCHAR(50)  NOT NULL,
    address    TEXT         NOT NULL,
    password   VARCHAR(255) NOT NULL,
    is_walk_in BOOLEAN DEFAULT FALSE,
    weight_kg  DECIMAL(5,2) NULL,
    height_cm  DECIMAL(5,1) NULL,
    patient_type ENUM('newborn','infant','adolescent','adult','elderly') DEFAULT 'adult',
    age        INT NULL,
    gender     ENUM('male','female') NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS doctors (
    id         INT AUTO_INCREMENT PRIMARY KEY,
    name       VARCHAR(255) NOT NULL,
    specialty  VARCHAR(255) NOT NULL,
    schedule   TEXT,
    experience INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS doctor_accounts (
    id         INT AUTO_INCREMENT PRIMARY KEY,
    doctor_id  INT NOT NULL UNIQUE,
    username   VARCHAR(100) UNIQUE NOT NULL,
    password   VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (doctor_id) REFERENCES doctors(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS admin_users (
    id                    INT AUTO_INCREMENT PRIMARY KEY,
    username              VARCHAR(100) UNIQUE NOT NULL,
    password              VARCHAR(255) NOT NULL,
    full_name             VARCHAR(255) NOT NULL,
    must_change_password  TINYINT(1)    NOT NULL DEFAULT 0,
    password_changed_at   DATETIME      NULL,
    failed_attempts       INT           NOT NULL DEFAULT 0,
    locked_until          DATETIME      NULL,
    created_at            TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS appointments (
    id                   INT AUTO_INCREMENT PRIMARY KEY,
    patient_id           INT NOT NULL,
    doctor_id            INT NOT NULL,
    appointment_date     DATE NOT NULL,
    appointment_time     TIME NOT NULL,
    appointment_duration INT DEFAULT 30,
    service_requested    VARCHAR(255) NULL,
    status               ENUM('pending','confirmed','cancelled','completed') DEFAULT 'pending',
    payment_status       ENUM('pending','paid') DEFAULT 'pending',
    is_urgent            BOOLEAN DEFAULT FALSE,
    notes                TEXT,
    result               TEXT NULL,
    result_date          DATETIME NULL,
    created_at           TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at           TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (patient_id) REFERENCES patients(id) ON DELETE CASCADE,
    FOREIGN KEY (doctor_id)  REFERENCES doctors(id)  ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS doctor_schedules (
    id           INT AUTO_INCREMENT PRIMARY KEY,
    doctor_id    INT NOT NULL,
    day_of_week  ENUM('Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday') NOT NULL,
    start_time   TIME NOT NULL,
    end_time     TIME NOT NULL,
    is_active    BOOLEAN DEFAULT TRUE,
    created_at   TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (doctor_id) REFERENCES doctors(id) ON DELETE CASCADE
);

-- Add columns if they don't exist (for existing databases)
-- Using stored procedures to make ALTERs idempotent
DROP PROCEDURE IF EXISTS __add_col__;
DELIMITER //
CREATE PROCEDURE __add_col__(IN p_table VARCHAR(64), IN p_col VARCHAR(64), IN p_def TEXT)
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns
        WHERE table_schema = DATABASE() AND table_name = p_table AND column_name = p_col
    ) THEN
        SET @sql = CONCAT('ALTER TABLE ', p_table, ' ADD COLUMN ', p_col, ' ', p_def);
        PREPARE stmt FROM @sql;
        EXECUTE stmt;
        DEALLOCATE PREPARE stmt;
    END IF;
END //
DELIMITER ;

CALL __add_col__('doctor_schedules', 'schedule_date', 'DATE AFTER doctor_id');
CALL __add_col__('patients', 'is_walk_in', 'BOOLEAN DEFAULT FALSE');
CALL __add_col__('patients', 'weight_kg', 'DECIMAL(5,2) NULL');
CALL __add_col__('patients', 'height_cm', 'DECIMAL(5,1) NULL');
CALL __add_col__('patients', 'patient_type', "ENUM('newborn','infant','adolescent','adult','elderly') DEFAULT 'adult'");
CALL __add_col__('patients', 'age', 'INT NULL');
CALL __add_col__('appointments', 'reschedule_count', 'INT DEFAULT 0');
CALL __add_col__('appointments', 'last_rescheduled_at', 'DATETIME NULL');
CALL __add_col__('appointments', 'result', 'TEXT NULL');
CALL __add_col__('appointments', 'result_date', 'DATETIME NULL');

DROP PROCEDURE IF EXISTS __add_col__;

CREATE TABLE IF NOT EXISTS lab_tests (
    id             INT AUTO_INCREMENT PRIMARY KEY,
    patient_id     INT NOT NULL,
    doctor_id      INT NOT NULL,
    appointment_id INT NULL,
    test_type      VARCHAR(255) NOT NULL,
    priority       ENUM('normal','urgent','stat') DEFAULT 'normal',
    status         ENUM('pending','processing','completed','cancelled') DEFAULT 'pending',
    scheduled_date DATE NULL,
    result         TEXT NULL,
    notes          TEXT NULL,
    created_at     TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at     TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (patient_id)     REFERENCES patients(id)      ON DELETE CASCADE,
    FOREIGN KEY (doctor_id)      REFERENCES doctors(id)       ON DELETE CASCADE,
    FOREIGN KEY (appointment_id) REFERENCES appointments(id)  ON DELETE SET NULL
);

-- ───────────────────────────────────────
-- Prenatal vitals & vaccination tracker
-- ───────────────────────────────────────

CREATE TABLE IF NOT EXISTS vitals (
    id             INT AUTO_INCREMENT PRIMARY KEY,
    patient_id     INT NOT NULL,
    visit_date     DATE NOT NULL,
    weight_kg      DECIMAL(5,2) NULL,
    blood_pressure VARCHAR(12)  NULL,
    heart_rate     INT NULL,
    fundal_height  DECIMAL(4,1) NULL,
    notes          TEXT NULL,
    created_at     TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (patient_id) REFERENCES patients(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS vaccinations (
    id                INT AUTO_INCREMENT PRIMARY KEY,
    patient_id        INT NOT NULL,
    vaccine_name      VARCHAR(120) NOT NULL,
    dose_label        VARCHAR(40)  NOT NULL,
    administered_date DATE NOT NULL,
    next_due_date     DATE NULL,
    notes             TEXT NULL,
    created_at        TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (patient_id) REFERENCES patients(id) ON DELETE CASCADE
);

-- ───────────────────────────────────────
-- Doctor unavailable time blocks
-- (admin can block specific times, e.g. doctor out 2PM-5PM)
-- ───────────────────────────────────────

CREATE TABLE IF NOT EXISTS doctor_time_blocks (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    doctor_id   INT NOT NULL,
    block_type  ENUM('date','weekly') NOT NULL DEFAULT 'date',
    block_date  DATE NULL,
    day_of_week VARCHAR(10) NULL,
    start_time  TIME NOT NULL,
    end_time    TIME NOT NULL,
    reason      VARCHAR(255) NULL,
    created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (doctor_id) REFERENCES doctors(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS reschedule_history (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    appointment_id  INT NOT NULL,
    old_date        DATE NOT NULL,
    old_time        TIME NOT NULL,
    new_date        DATE NOT NULL,
    new_time        TIME NOT NULL,
    rescheduled_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (appointment_id) REFERENCES appointments(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS walk_ins (
    id            INT AUTO_INCREMENT PRIMARY KEY,
    patient_id    INT NOT NULL,
    doctor_id     INT NOT NULL,
    arrival_date  DATE NOT NULL,
    arrival_time  TIME NOT NULL,
    status        ENUM('waiting','in_service','served','cancelled') DEFAULT 'waiting',
    notes         VARCHAR(255) NULL,
    created_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (patient_id) REFERENCES patients(id) ON DELETE CASCADE,
    FOREIGN KEY (doctor_id)  REFERENCES doctors(id)  ON DELETE CASCADE
);

-- ───────────────────────────────────────
-- INDEXES
-- ───────────────────────────────────────

CREATE INDEX idx_patient_email    ON patients(email);
CREATE INDEX idx_appointment_date ON appointments(appointment_date);
CREATE INDEX idx_appointment_doctor ON appointments(doctor_id, appointment_date);
CREATE INDEX idx_appointment_patient ON appointments(patient_id);
CREATE INDEX idx_lab_patient   ON lab_tests(patient_id);
CREATE INDEX idx_lab_doctor    ON lab_tests(doctor_id);
CREATE INDEX idx_lab_status    ON lab_tests(status);
CREATE INDEX idx_lab_scheduled ON lab_tests(scheduled_date);
CREATE INDEX idx_vitals_patient       ON vitals(patient_id);
CREATE INDEX idx_vaccinations_patient ON vaccinations(patient_id);
CREATE INDEX idx_walkin_doctor_date   ON walk_ins(doctor_id, arrival_date, arrival_time);

-- ───────────────────────────────────────
-- SEED DATA
-- ───────────────────────────────────────

INSERT INTO doctors (id, name, specialty, schedule, experience) VALUES
(1, 'Elgely Dayaganon',      'Obstetrics & Gynecology', 'Mon-Fri: 9AM-5PM',       15),
(2, 'Maverick Bautista',     'High-Risk Pregnancy',     'Tue-Sat: 10AM-6PM',      20),
(3, 'Alwyn Beloy',           'Reproductive Health',     'Mon-Wed-Fri: 8AM-4PM',   12),
(4, 'Jae Kristian Dela Cruz','Gynecologic Surgery',     'Mon-Thu: 1PM-7PM',       18)
ON DUPLICATE KEY UPDATE name = name;

-- Default admin (username: admin, password: admin123) — forced to change on first login
INSERT INTO admin_users (username, password, full_name, must_change_password) VALUES
('admin', '$2y$10$0Av257SF78.iqpF7aU.v4e9Uk.vQnoJilaSvdHMwDQ/GIjA30KoDa', 'System Administrator', 1)
ON DUPLICATE KEY UPDATE username = username;

INSERT INTO doctor_schedules (doctor_id, day_of_week, start_time, end_time, is_active) VALUES
(1, 'Monday',    '09:00:00', '17:00:00', TRUE),
(1, 'Tuesday',   '09:00:00', '17:00:00', TRUE),
(1, 'Wednesday', '09:00:00', '17:00:00', TRUE),
(1, 'Thursday',  '09:00:00', '17:00:00', TRUE),
(1, 'Friday',    '09:00:00', '17:00:00', TRUE),
(2, 'Tuesday',   '10:00:00', '18:00:00', TRUE),
(2, 'Wednesday', '10:00:00', '18:00:00', TRUE),
(2, 'Thursday',  '10:00:00', '18:00:00', TRUE),
(2, 'Friday',    '10:00:00', '18:00:00', TRUE),
(2, 'Saturday',  '10:00:00', '18:00:00', TRUE),
(3, 'Monday',    '08:00:00', '16:00:00', TRUE),
(3, 'Wednesday', '08:00:00', '16:00:00', TRUE),
(3, 'Friday',    '08:00:00', '16:00:00', TRUE),
(4, 'Monday',    '13:00:00', '19:00:00', TRUE),
(4, 'Tuesday',   '13:00:00', '19:00:00', TRUE),
(4, 'Wednesday', '13:00:00', '19:00:00', TRUE),
(4, 'Thursday',  '13:00:00', '19:00:00', TRUE)
ON DUPLICATE KEY UPDATE start_time = start_time;
