-- ═══════════════════════════════════════════════════════════════
-- Email OTP authentication — email_tokens table
-- Run this once against the toddcare database, OR simply let
-- otp_send.php auto-create it (it checks and creates if missing).
-- ═══════════════════════════════════════════════════════════════
USE toddcare;

CREATE TABLE IF NOT EXISTS email_tokens (
    id           INT AUTO_INCREMENT PRIMARY KEY,
    email        VARCHAR(255) NOT NULL,
    token        VARCHAR(64)  NOT NULL,
    expires_at   DATETIME     NOT NULL,
    used         TINYINT(1)   DEFAULT 0,
    created_at   TIMESTAMP    DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_email (email),
    INDEX idx_token (token)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
